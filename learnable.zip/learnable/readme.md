# coffeefy
Native Notification App

#### run dev
_if problems show up while running the ``` php artisan serve ``` command,_<br />**_follow these steps:_**
<br/>
1. Open the Terminal and go to the Project folder
2. Run: ```composer update --no-scripts ``` or ```composer install ```
3. Clear the config like:  ``` php artisan config:clear ```
4. Generate a Key like: ``` php artisan key:generate```
<br/>
<br/>
And at the end the command 
``` php artisan serve``` 
should work!