<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToEventsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('events', function(Blueprint $table)
		{
			$table->foreign('lesson', 'events_lessons_fk_2')->references('id')->on('lessons')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('type', 'events_types_fk')->references('id')->on('event_types')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('creator', 'events_users_fk_3')->references('id')->on('users')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('events', function(Blueprint $table)
		{
			$table->dropForeign('events_lessons_fk_2');
			$table->dropForeign('events_types_fk');
			$table->dropForeign('events_users_fk_3');
		});
	}

}
