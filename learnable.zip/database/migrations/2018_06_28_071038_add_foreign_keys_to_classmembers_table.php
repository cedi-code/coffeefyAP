<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToClassmembersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('classmembers', function(Blueprint $table)
		{
			$table->foreign('class', 'classmembers_classes_fk')->references('id')->on('classes')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('pupil', 'classmembers_users_fk')->references('id')->on('users')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('classmembers', function(Blueprint $table)
		{
			$table->dropForeign('classmembers_classes_fk');
			$table->dropForeign('classmembers_users_fk');
		});
	}

}
