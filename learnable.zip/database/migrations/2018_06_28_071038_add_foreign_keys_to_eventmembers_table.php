<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToEventmembersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('eventmembers', function(Blueprint $table)
		{
			$table->foreign('event', 'eventmembers_event_fk_2')->references('id')->on('events')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('user', 'eventmembers_users_fk')->references('id')->on('users')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('eventmembers', function(Blueprint $table)
		{
			$table->dropForeign('eventmembers_event_fk_2');
			$table->dropForeign('eventmembers_users_fk');
		});
	}

}
