<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('username')->unique('users_username_uindex');
			$table->string('email')->unique('users_email_uindex');
			$table->string('hash');
			$table->text('first_name', 65535);
			$table->text('last_name', 65535);
			$table->boolean('is_teacher')->default(0);
			$table->boolean('is_admin')->default(0);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
