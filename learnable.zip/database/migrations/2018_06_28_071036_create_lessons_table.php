<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLessonsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('lessons', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('course')->index('lessons_courses_fk');
			$table->integer('class')->index('lessons_classes_fk_2');
			$table->integer('teacher')->index('lessons_users_fk_3');
			$table->dateTime('start');
			$table->dateTime('end');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('lessons');
	}

}
