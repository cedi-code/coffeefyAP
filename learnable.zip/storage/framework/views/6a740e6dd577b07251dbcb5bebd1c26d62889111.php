<?php echo $__env->make('.scriptsBinding.work_in_progress_init', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>

    <section id="container">
        <section id="wrapper">
            <h1 id="content">
                &lt;/ Coffeefy <?= $status ?> &gt;
            </h1>
        </section>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.scriptsBinding.work_in_progress_set', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>