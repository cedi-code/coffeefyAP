<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classmembers extends Model
{
    protected $table = 'classmembers';
}
