<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Eventmembers extends Model
{
    protected $table = 'eventmembers';
}
