<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Lessons extends Model
{
    protected $table = 'lessons';
	
	public static function showDateSchedule(){
        $date = $_GET['date'];

        $result = DB::table('lessons')->whereDate('start', $date)->get();

		return json_encode($result);
    }
}
