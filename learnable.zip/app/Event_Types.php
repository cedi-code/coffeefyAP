<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Event_Types extends Model
{
    protected $table = 'event_types';
}
