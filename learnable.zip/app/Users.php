<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Users extends Model
{
    protected $table = 'users';

    public static function login(){
        $query = $_GET['query'];
        $hash = $_GET['password'];

        $result = DB::table('users')->where('username', 'LIKE', $query)->orWhere('email', 'LIKE', $query)->first();

        if (password_verify($hash, $result->hash)){
            return json_encode((array) $result);
        }
        return null;
    }
}
