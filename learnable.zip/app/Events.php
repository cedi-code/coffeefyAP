<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Events extends Model
{
    protected $table = 'events';

    public static function getAll(){
        $result = DB::table('events')
            ->select('events.id as id', 'event_types.type as type', 'lessons.start as lesson', 'users.username as creator', 'events.title as title', 'events.description as description')
            ->leftJoin('event_types', 'events.type', '=', 'event_types.id')
            ->leftJoin('lessons', 'events.lesson', '=', 'lessons.id')
            ->leftJoin('users', 'events.creator', '=', 'users.id')
            ->get();

        return $result;
    }
}
