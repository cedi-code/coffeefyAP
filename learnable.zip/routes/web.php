<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    $status = 'dev';

    return view('components.work_in_progress', compact('status'));
});

// Users
Route::get('data/users', 'UserController@index');
Route::get('data/users/teachers', 'UserController@showTeachers');
Route::get('data/users/teachers/{user}', 'UserController@showTeacherById');
Route::get('data/users/admins', 'UserController@showAdmins');
Route::get('data/users/{user}', 'UserController@show');

Route::get('/login', 'UserController@login');
Route::get('/token', 'UserController@token');

// Classes
Route::get('data/classes', 'ClassesController@index');
Route::get('data/classes/{class}', 'ClassesController@show');

// Schools
Route::get('data/schools', 'SchoolsController@index');
Route::get('data/schools/{school}', 'SchoolsController@show');

// Locations
Route::get('data/locations', 'LocationsController@index');
Route::get('data/locations/{location}', 'LocationsController@show');

// Courses
Route::get('data/courses', 'CoursesController@index');
Route::get('data/courses/{cours}', 'CoursesController@show');

// Event_types
Route::get('data/event_types', 'Event_TypesController@index');
Route::get('data/event_types/{event_type}', 'Event_TypesController@show');

// Events
Route::get('data/events', 'EventsController@index');
Route::get('data/events/{event}', 'EventsController@show');

// Lessons
Route::get('data/lessons', 'LessonsController@index');
Route::get('data/lessons/{lesson}', 'LessonsController@show');
Route::get('data/lessons/whereDate/{date}', 'LessonsController@showLessonsWhereDate');
Route::get('data/lessons/whereClass/{class}', 'LessonsController@showLessonsWhereClass');
Route::get('data/dateSchedule', 'LessonsController@showDateSchedule');

// Classmembers
Route::get('data/classmembers', 'ClassmembersController@index');
Route::get('data/classmembers/class/{class}', 'ClassmembersController@showClass');
Route::get('data/classmembers/pupil/{user}', 'ClassmembersController@showPupil');

// Eventmembers
Route::get('data/eventmembers', 'EventmembersController@index');
Route::get('data/eventmembers/event/{event}', 'EventmembersController@showEvent');
Route::get('data/eventmembers/user/{user}', 'EventmembersController@showUser');


// Join example
Route::get('data/classes/school', function () {

    // TODO vermeiden der gleichnamigen atributte!

    $data = DB::table('classes AS c')
        ->join('users AS u', 'u.id', '=', 'c.teacher')
        ->join('schools AS s', 's.id', '=', 'c.school')
        ->select('s.title AS schoolTitle', 'c.title AS classTitle')
        ->get();

    return view('components.test_output', compact('data'));
});
