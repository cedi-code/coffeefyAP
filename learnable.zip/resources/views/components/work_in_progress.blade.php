
@extends('.layouts.master')

@include('.scriptsBinding.work_in_progress_init')

@section('content')

    <section id="container">
        <section id="wrapper">
            <h1 id="content">
                &lt;/ Coffeefy <?= $status ?> &gt;
            </h1>
        </section>
    </section>

@endsection

@include('.scriptsBinding.work_in_progress_set')