@extends('.layouts.master')

@include('.scriptsBinding.work_in_progress_init')

@section('content')

<section id="container">
    <section id="wrapper">
        <div id="content-output">


            <pre>
                {{print_r($data)}}
            </pre>

        </div>
    </section>
</section>

@endsection

@include('.scriptsBinding.work_in_progress_set')